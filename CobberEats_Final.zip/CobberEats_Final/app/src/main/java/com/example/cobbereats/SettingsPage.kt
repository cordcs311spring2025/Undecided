package com.example.cobbereats

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class SettingsPage: AppCompatActivity(){
    private lateinit var profileImageView: ImageView
    private lateinit var userPreferences: UserPreferences

    // Activity Result Launcher for picking an image
    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                val savedFile = saveImageToInternalStorage(it)
                if (savedFile != null) {
                    profileImageView.setImageBitmap(BitmapFactory.decodeFile(savedFile.absolutePath))
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings)
        enableEdgeToEdge()

        userPreferences = UserPreferences(this)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.settingsLayout)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize Buttons
        val changeProfileButton: Button = findViewById(R.id.changeProfilePictureButton)
        val backButton: Button = findViewById(R.id.backButton)
        val changeUsernameButton: Button = findViewById(R.id.changeUsernameButton)
        val changePasswordButton: Button = findViewById(R.id.changePasswordButton)
        val deleteAccountButton: Button = findViewById(R.id.deleteAccountButton)

        // Open gallery when button is clicked
        changeProfileButton.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        // Navigate back to the home page
        backButton.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
        }

        // Change Username click listener
        changeUsernameButton.setOnClickListener{
            showChangeDialog("Username","Enter New Username", "username", false)
        }

        // Change Password click listener
        changePasswordButton.setOnClickListener{
            showChangeDialog("Password", "Enter New Password", "password", true)
        }

        // Delete Account click listener
        deleteAccountButton.setOnClickListener{
            showDeleteAccountDialog()
        }
    }

    // Saves the selected image to internal storage
    private fun saveImageToInternalStorage(imageUri: Uri): File? {
        try {
            val fileName = "profile_image.jpg"
            val file = File(filesDir, fileName)

            // Open input stream from the selected image
            val inputStream: InputStream? = contentResolver.openInputStream(imageUri)
            val outputStream = FileOutputStream(file)

            // Convert the input stream to a bitmap and save as a file
            val bitmap = BitmapFactory.decodeStream(inputStream)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)

            outputStream.flush()
            outputStream.close()
            inputStream?.close()

            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun showChangeDialog(title: String, hint: String, key: String, isPassword: Boolean) {
        // Create an EditText to input the new username or password
        val editText = EditText(this).apply {
            this.hint = hint
        }
        // Create and configure the AlertDialog for both username and password change
        val dialog = AlertDialog.Builder(this)
            .setTitle("Change $title")
            .setMessage("Please enter your new $title.")
            .setView(editText)
            .setPositiveButton("OK") { _, _ ->
                val newValue = editText.text.toString()
                if (newValue.isNotEmpty()) {
                    // Save the new username or password (encrypted if it's a password)
                    if (isPassword){
                        userPreferences.savePassword(newValue)
                    } else{
                        userPreferences.saveUsername(newValue)
                    }
                    Toast.makeText(this, "$title changed!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "$title cannot be empty", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show() // Show the dialog
    }

    private fun showDeleteAccountDialog(){
        val dialog = AlertDialog.Builder(this)
            .setTitle("Delete Account")
            .setMessage("Are you sure you wish to delete your account?")
            .setPositiveButton("Yes") { _, _ ->
                disableAccount()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.show()
    }

    private fun disableAccount(){
        userPreferences.disableAccount()
        Toast.makeText(this, "Your account has been disabled.", Toast.LENGTH_SHORT).show()

        // Go back to login screen
        finish()
    }
}