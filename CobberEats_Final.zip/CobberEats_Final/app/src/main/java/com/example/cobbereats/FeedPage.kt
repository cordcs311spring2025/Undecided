package com.example.cobbereats

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cobbereats.Post
import com.example.cobbereats.PostAdapter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class FeedPage : AppCompatActivity() {
    private lateinit var editText: EditText
    private lateinit var button: Button
    private lateinit var recyclerView: RecyclerView
    private val postList = mutableListOf<Post>()
    private lateinit var adapter: PostAdapter

    override fun onPause() {
        super.onPause()
        savePostsToPreferences()
    }

    override fun onResume() {
        super.onResume()
        loadPostsFromPreferences()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.feed)
        enableEdgeToEdge()

        editText = findViewById(R.id.edit_text)
        button = findViewById(R.id.button_id)
        recyclerView = findViewById(R.id.recycler_view)
        adapter = PostAdapter(postList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Menu Button
        val menuButton: Button = findViewById(R.id.menuButton)
        menuButton.setOnClickListener {
            val intent = Intent(this, MenuPage::class.java)
            startActivity(intent)
        }

        // Home Button
        val homeButton: Button = findViewById(R.id.homeButton)
        homeButton.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
        }

        // Submit/Post Button
        button.setOnClickListener {
            val userInput = editText.text.toString()
            if (userInput.isNotBlank()) {
                val userPreferences = UserPreferences(this)
                val username = userPreferences.getUsername()
                val newPost = Post(text = userInput, username = username)
                postList.add(0, newPost) // Add new post at the top
                adapter.notifyItemInserted(0)
                recyclerView.scrollToPosition(0)
                editText.text.clear()
                savePostsToPreferences() // Save posts whenever a new one is added
            }
        }
    }

    private fun savePostsToPreferences() {
        val sharedPref = getSharedPreferences("FeedPrefs", MODE_PRIVATE)
        val gson = Gson()
        val json = gson.toJson(postList) // Convert post list to JSON
        sharedPref.edit().putString("posts", json).apply() // Save JSON string
    }

    private fun loadPostsFromPreferences() {
        val sharedPref = getSharedPreferences("FeedPrefs", MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPref.getString("posts", "[]") // Load saved JSON string, default to empty list
        val type = object : TypeToken<List<Post>>() {}.type
        val loadedPosts: List<Post> = gson.fromJson(json, type) // Convert JSON string to list of posts
        postList.clear()
        postList.addAll(loadedPosts)
        adapter.notifyDataSetChanged()
    }
}