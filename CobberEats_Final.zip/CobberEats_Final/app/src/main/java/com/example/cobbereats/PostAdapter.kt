package com.example.cobbereats

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostAdapter(private val posts: List<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>(){

    class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val postUsername: TextView = view.findViewById(R.id.username)
        val postText: TextView = view.findViewById(R.id.post_text)
        val postTimestamp: TextView = view.findViewById(R.id.post_timestamp) // Add timestamp
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        holder.postUsername.text = post.username
        holder.postText.text = post.text
        holder.postTimestamp.text = post.timestamp  // Set timestamp text

    }

    override fun getItemCount(): Int = posts.size
}
