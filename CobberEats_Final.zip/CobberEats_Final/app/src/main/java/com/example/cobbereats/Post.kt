package com.example.cobbereats
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Post(val text: String, val timestamp: String = getCurrentTime(), val username:String) {
    companion object {
        fun getCurrentTime(): String {
            val dateFormat = SimpleDateFormat("hh:mm a - MMM dd, yyyy", Locale.getDefault())
            return dateFormat.format(Date())
        }
    }
}





