package com.example.cobbereats

import android.content.Intent
import android.graphics.BitmapFactory
import android.widget.Button
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File

class HomePage : AppCompatActivity() {
    private lateinit var profileImageView: de.hdodenhof.circleimageview.CircleImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.home)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }

        //Reference Buttons
        val logoutButton: Button = findViewById(R.id.logoutButton)
        val settingsButton: ImageButton = findViewById(R.id.settingsButton)
        val feedButton: Button = findViewById(R.id.feedButton)
        val aboutButton: Button = findViewById(R.id.aboutButton)

        logoutButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        aboutButton.setOnClickListener{
            startActivity(Intent(this, AboutUs::class.java))
        }
        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsPage::class.java))
        }

        feedButton.setOnClickListener {
            startActivity(Intent(this, FeedPage::class.java))
        }
        profileImageView = findViewById(R.id.profile_image)
        loadProfileImage()
    }



    private fun loadProfileImage() {
        val file = File(filesDir, "profile_image.jpg")
        if (file.exists()) {
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            profileImageView.setImageBitmap(bitmap)
        } else {
            profileImageView.setImageResource(R.drawable.icon_account_circle)
        }
    }
}