package com.example.cobbereats

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var usernameInput: EditText
    lateinit var passwordInput: EditText
    lateinit var loginBtn: Button
    lateinit var newAccountBtn: Button
    lateinit var userPreferences: UserPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enableEdgeToEdge()

        usernameInput = findViewById(R.id.username_input)
        passwordInput = findViewById(R.id.password_input)
        loginBtn = findViewById(R.id.login_btn)
        newAccountBtn = findViewById(R.id.newAccount_button)
        userPreferences = UserPreferences(this)

        // check saved username and password
        loginBtn.setOnClickListener {
            val inputUsername = usernameInput.text.toString().trim()
            val inputPassword = passwordInput.text.toString().trim()

            val savedUsername = userPreferences.getUsername()
            val savedPassword = userPreferences.getPassword()
            Log.i(
                "LoginCheck",
                "Input: $inputUsername / $inputPassword, Saved: $savedUsername / $savedPassword"
            )

            if (savedUsername.isEmpty() || savedPassword.isEmpty()) {
                Toast.makeText(this, "Please create an account first", Toast.LENGTH_SHORT).show()
            } else {
                if (inputUsername == savedUsername && inputPassword == savedPassword) {
                    if (userPreferences.isUserDisabled()) {
                        Toast.makeText(this, "This account is disabled.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                        // Go to HomePage
                        val intent = Intent(this, HomePage::class.java)
                        startActivity(intent)
                        finish()
                    }
                } else {
                    Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
                }
            }
        }

        newAccountBtn.setOnClickListener{
            showNewAccountDialog()
        }
    }
    private fun showNewAccountDialog() {
        // Create horizontal layout for username
        val usernameLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val usernameLabel = TextView(this@MainActivity).apply {
                this.text = getString(R.string.username_text)
                setPadding(0, 0, 16, 0) // Space between label and box
            }
            val usernameEditText = EditText(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) // Stretch EditText
            }
            addView(usernameLabel)
            addView(usernameEditText)
        }

        // Create horizontal layout for password
        val passwordLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val passwordLabel = TextView(this@MainActivity).apply {
                this.text = getString(R.string.password_text)
                setPadding(0, 0, 16, 0)
            }
            val passwordEditText = EditText(this@MainActivity).apply {
                transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            addView(passwordLabel)
            addView(passwordEditText)
        }

        // Main vertical layout
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 10) // Optional nice padding
            addView(usernameLayout)
            addView(passwordLayout)
        }

        // Build the AlertDialog
        val dialog = AlertDialog.Builder(this)
            .setTitle("Create New Account")
            .setMessage("Please enter a username and password.")
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                val username = (usernameLayout.getChildAt(1) as EditText).text.toString().trim()
                val password = (passwordLayout.getChildAt(1) as EditText).text.toString().trim()

                if (username.isNotEmpty() && password.isNotEmpty()) {
                    userPreferences.saveUsername(username)
                    userPreferences.savePassword(password)
                    Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show()
                }
            }
                .setNegativeButton("Cancel", null)
                .create()
        dialog.show()
    }
}


