package com.example.cobbereats

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MenuPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu)

        val backButton: Button =findViewById(R.id.backButton)

        backButton.setOnClickListener{
            startActivity(Intent(this, FeedPage::class.java))

        }

        val menuLink: TextView = findViewById(R.id.menu_link)

        // click listener to open the webpage
        menuLink.setOnClickListener {
            val url = "https://www.concordia.edu/services/dining-services.html"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)


        }
    }
}