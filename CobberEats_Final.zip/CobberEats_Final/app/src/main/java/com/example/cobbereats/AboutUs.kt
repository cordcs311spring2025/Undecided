package com.example.cobbereats

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class AboutUs : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.about_us)

        val backButton: Button = findViewById(R.id.backButton)

        backButton.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))

        }
    }
}
