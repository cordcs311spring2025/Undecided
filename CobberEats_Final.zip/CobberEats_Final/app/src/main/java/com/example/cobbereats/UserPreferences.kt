package com.example.cobbereats

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
    private val encryptedPrefs: SharedPreferences

    // Uses 2 different versions in case one doesn't work
    init {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        encryptedPrefs = try {
            EncryptedSharedPreferences.create(
                context,
                "secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.deleteSharedPreferences("secure_prefs")
            EncryptedSharedPreferences.create(
                context,
                "secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
    }

    fun saveUsername(username: String) {
        prefs.edit().putString("username", username).apply()
    }

    fun getUsername(): String {
        return prefs.getString("username", "") ?: ""
    }

    fun savePassword(password: String) {
        encryptedPrefs.edit().putString("password_${getUsername()}", password).apply()
    }

    fun getPassword(): String {
        return encryptedPrefs.getString("password_${getUsername()}", "") ?: ""
    }

    // Disables and removes password
    fun disableAccount() {
        val currentUser = getUsername()
        prefs.edit().putBoolean("isDisabled_$currentUser", true).apply()
        encryptedPrefs.edit().remove("password_$currentUser").apply()
    }

    fun isUserDisabled(): Boolean {
        return prefs.getBoolean("isDisabled_${getUsername()}", false)
    }

}